/*global document, window, prompt*/

window.onload = function validateUder() {

    "use strict";
    var name = prompt("Enter your name - ahmed in current case :");

    if (name == 'ahmed') {
        window.location('index.html');

    } else {
        prompt('wrong name please try again');
    }
}



function hoverButton() {
    "use strict";
    var button = document.getElementById('hoverButton');
    button.style.backgroundColor = '#888';
    button.style.color = 'black';

}

function outButton() {
    "use strict";
    var button = document.getElementById('hoverButton');
    button.style.backgroundColor = '#3ddb9c';
    button.style.color = 'white';
}

function actionVisibility1() {
    "use strict";
    var btn = document.getElementById('info');
    btn.style.visibility = 'visible';
}


function actionVisibility2() {
    "use strict";
    var btn = document.getElementById('info');
    btn.style.visibility = 'hidden';
}

var x = 0,
    y = 0,
    z = 0;

function clicked1() {
    "use strict";
    x = x + 1;
    document.getElementById('img1').innerHTML = x;

}

function clicked2() {
    "use strict";
    y = y + 1;
    document.getElementById('img2').innerHTML = y;

}

function clicked3() {
    "use strict";
    z = z + 1;
    document.getElementById('img3').innerHTML = z;

}
